package com.tripmaven;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TripmavenrestapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(TripmavenrestapiApplication.class, args);
	}

}
