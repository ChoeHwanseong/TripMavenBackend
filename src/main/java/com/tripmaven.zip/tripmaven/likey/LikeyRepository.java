package com.tripmaven.likey;

import org.springframework.data.jpa.repository.JpaRepository;

public interface LikeyRepository extends JpaRepository<LikeyEntity, Long> {

}
